This test has been provided for you so that you can see one example, however, you should be creating your own tests to check that your code runs as expected.
