# import pandas as pd
import math
import sys


class Node:
    """
    imprtant data of each row data will be saved as node in value part of two dictionaries
    """

    def __init__(self):
        self.id = ""
        self.dt = ""
        self.amt = 0
        self.year = 0
        self.name = ""


def run(data_path, saving_file, percentile):
    """
    :param data_path:  the input data file path
    :param saving_file: the saving file path
    :param percentile: the percentile
    """

    # Defining two dictionary for saving list of donors and the campaigns that donors donated to
    donor_dict = dict()
    campaign_dict = dict()

    # creating the output file
    f_write = open(saving_file, "w")
    with open(data_path) as fp:
        line = fp.readline()
        while line:
            splited_line = line.split("|")

            if len(splited_line[15]) > 0:
                line = fp.readline()
                continue
            # Concatenating donor name and his/her zip code as key for donors dictionary
            name_zipcode = splited_line[7] + '|' + splited_line[10][0:5]
            node = Node()
            node.name = splited_line[7]
            node.amt = int(splited_line[14])
            node.dt = splited_line[13]
            node.id = splited_line[0]
            try:
                # check for malformed date and extracting year from donation date
                if len(splited_line[13][4:12]) != 4:
                    line = fp.readline()
                    continue
                node.year = int(splited_line[13][4:12])
            except:
                line = fp.readline()
                continue
            # Concatenating campaign id and its zip code as key for campaign dictionary
            id_zipcode = splited_line[0] + '|' + splited_line[10][0:5]

            if name_zipcode not in donor_dict:
                # save the node in value of dictionary as an array
                donor_dict[name_zipcode] = [node]
            else:
                # append the new node to value of existing entry in dictionary
                donor_dict[name_zipcode] = donor_dict[name_zipcode] + [node]
                lst = [node.amt]
                if id_zipcode in campaign_dict:
                    list_same_campaign_doner = campaign_dict[id_zipcode]
                    for item in list_same_campaign_doner:
                        if item.year == node.year:
                            lst.append(item.amt)

                p_index = math.ceil((percentile / 100) * len(lst))  # finding index of percentile in list of numbers
                calculated_percentile = sorted(lst)[p_index - 1]  # returning the percentile
                # constructing output line and save it into output file
                f_write.write(id_zipcode + "|" + str(node.year) + "|" + str(calculated_percentile) + "|" + str(sum(lst)) + "|" + str(len(lst)) + "\n")

            if id_zipcode not in campaign_dict:
                campaign_dict[id_zipcode] = [node]
            else:
                campaign_dict[id_zipcode] = campaign_dict[id_zipcode] + [node]

            line = fp.readline()

    f_write.close()


if __name__ == '__main__':
    with open(sys.argv[2]) as fp:
        line = fp.readline()
        percentile = int(line)

    run(sys.argv[1], sys.argv[3], percentile)
